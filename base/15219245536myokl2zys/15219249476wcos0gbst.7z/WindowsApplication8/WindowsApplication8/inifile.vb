﻿


Imports System.IO

Public Class inifile
    '------------------------------------------------
    ' Name:
    '
    ' inifile.vb
    '
    ' Description:
    '
    ' Simple minded implementation of an inifile reader/writer class. The functionality is all
    ' here except that error checking is minimal, everythinig is case sensitive and there is
    ' no provision to maintain blank lines or comments.
    '
    ' Properties:
    '
    ' status - String - blank or a string indicating the nature of the error
    '
    ' Methods:
    '
    ' Read(filename)
    '
    ' Read the given inifile into memory
    '
    ' Write()
    '
    ' Write the in-memory inifile to the last read inifile on disk
    '
    ' Write(filename)
    '
    ' Write the in0memory inifile to the given file and make it the current file
    '
    ' GetValue(section,setting)
    '
    ' Return the value of the given setting in the given section
    '
    ' SetValue(section,setting,value)
    '
    ' Set the given setting in the given section to the given valaue (create as needed)
    '
    ' Delete(section)
    '
    ' Delete the given section and all of its settings
    '
    ' Delete(section,setting)
    '
    ' Delete the given setting ini the given section
    '
    ' Serialize()
    '
    ' Convert the in-memory inifile to a string (lines end with vbCrLf) with encryption
    '
    ' Serialize2()
    '
    ' Convert the in-memory inifile to a string (lines end with vbCrLf) without encryption
    '
    ' Notes:
    '
    ' The in-memory inifile is maintained as nested dictionaries. Each section is a dictionary
    ' where the key is the setting name and the value is the string value of the setting. The
    ' entire structure is also a dictionary where the key is the section name (including the [
    ' and ] delimiters) and the value is the dictionary of the associated settings.

    '------------------------------------------------
    Public status As String = ""
    Private m_inifile As New Dictionary(Of String, Dictionary(Of String, String))
    Private m_filename As String = ""
    Public Function GetValue(section As String, setting As String) As String
        'return the value of <setting> in [section]
        'return Nothing if not defined
        status = ""
        If Not m_inifile.ContainsKey(section) Then
            status = section & " not found"
            Return Nothing
        End If
        If Not m_inifile(section).ContainsKey(setting) Then
            status = section & setting & " not found"
            Return Nothing
        End If
        Return m_inifile(section)(setting)
    End Function
    Public Sub SetValue(section As String, setting As String, value As String)
        'set the value of <setting> in [section]
        status = ""
        'create [section] if not defined
        If Not section.StartsWith("[") Then
            section = "[" & section
        End If
        If Not section.EndsWith("]") Then
            section &= "]"
        End If
        If Not m_inifile.ContainsKey(section) Then
            m_inifile.Add(section, New Dictionary(Of String, String))
        End If
        'create <setting> if not defined and set value
        If Not m_inifile(section).ContainsKey(setting) Then
            m_inifile(section).Add(setting, value)
        Else
            m_inifile(section)(setting) = value
        End If
    End Sub
    Public Function Delete(section As String) As Boolean
        'delete the given section and all of its settings
        status = ""
        If Not m_inifile.ContainsKey(section) Then
            status = section & " not found"
            Return False
        End If
        m_inifile.Remove(section)
        Return True
    End Function
    Public Function Delete(section As String, setting As String) As Boolean
        'delete the given setting from the given section
        status = ""
        If Not m_inifile.ContainsKey(section) Then
            status = section & " not found"
            Return False
        End If
        If Not m_inifile(section).ContainsKey(setting) Then
            status = section & setting & " not found"
            Return False
        End If
        m_inifile(section).Remove(setting)
        Return True
    End Function
    Public Function Read(filename As String) As Boolean
        'read the given ini file
        Dim section As String = Nothing
        Dim setting As String = Nothing
        Dim value As String = Nothing
        Dim equals As Integer
        status = ""
        If Not My.Computer.FileSystem.FileExists(filename) Then
            status = filename & " not found"
            Return False
        End If
        'get rid of any existing entries
        m_inifile.Clear()
        m_filename = filename
        For Each line As String In System.IO.File.ReadAllLines(m_filename)
            'process either a section "[" or a setting
            If line.StartsWith("[") Then
                section = Trim(line)
                m_inifile.Add(section, New Dictionary(Of String, String))
            Else
                equals = InStr(line, "=")
                setting = Trim(line.Substring(0, equals - 1))
                value = Decrypt(Trim(line.Substring(equals)))
                m_inifile(section).Add(setting, value)
            End If
        Next
        Return True
    End Function
    Public Function Write(filename As String) As Boolean
        'write the inifile to the given filename and set filename as
        'the current inifile
        status = ""
        Try
            File.WriteAllText(filename, Serialize())
            m_filename = filename
        Catch ex As Exception
            status = ex.Message
            Return False
        End Try
        Return True
    End Function
    Public Function Write() As Boolean
        'write the inifile to the current file
        Return IIf(m_filename = "", False, Write(m_filename))
    End Function
    Public Function Serialize() As String
        'convert the in-memory inifile to a string
        Dim builder As New System.Text.StringBuilder
        For Each section As String In m_inifile.Keys
            builder.Append(section & vbCrLf)
            For Each setting As String In m_inifile(section).Keys
                builder.Append(setting & "=" & Encrypt(m_inifile(section)(setting)) & vbCrLf)
            Next
        Next
        Return builder.ToString
    End Function
    Public Function Serialize2() As String
        'convert the in-memory inifile to a string (no encryption)
        Dim builder As New System.Text.StringBuilder
        For Each section As String In m_inifile.Keys
            builder.Append(section & vbCrLf)
            For Each setting As String In m_inifile(section).Keys
                builder.Append(setting & "=" & m_inifile(section)(setting) & vbCrLf)
            Next
        Next
        Return builder.ToString
    End Function
End Class
