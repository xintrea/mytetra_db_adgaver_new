﻿Public Class inifile2
    Private m_inifile As New Dictionary(Of String, Dictionary(Of String, String))
    Public Function GetValue(section As String, setting As String) As String
        'return the value of <setting> in [section]
        'return Nothing if not defined
        If m_inifile.ContainsKey(section) Then
            If m_inifile(section).ContainsKey(setting) Then
                Return m_inifile(section)(setting)
            End If
        End If
        Return Nothing
    End Function
    Public Sub SetValue(section As String, setting As String, value As String)
        'set the value of <setting> in [section]
        'create [section] if not defined
        If Not m_inifile.ContainsKey(section) Then
            m_inifile.Add(section, New Dictionary(Of String, String))
        End If
        'create <setting> if not defined and set value
        If Not m_inifile(section).ContainsKey(setting) Then
            m_inifile(section).Add(setting, value)
        Else
            m_inifile(section)(setting) = value
        End If
    End Sub
    Public Function Read(filename As String) As Boolean
        Dim section As String = Nothing 'section name (includes [])
        Dim setting As String = Nothing 'setting name
        Dim value As String = Nothing 'setting value
        Dim equals As Integer 'index of first "="
        'get rid of any existing entries
        m_inifile.Clear()
        For Each line As String In System.IO.File.ReadAllLines("C:\Users\Shinkina\Desktop\IniReader\lcE.ini")
            'process either a section "[" or a setting
            'settings are split at the first "=" into setting=value pairs
            If line.StartsWith("[") Then
                section = Trim(line)
                m_inifile.Add(section, New Dictionary(Of String, String))
            Else
                equals = InStr(line, "=")
                setting = line.Substring(0, equals - 1)
                value = line.Substring(equals)
                m_inifile(section).Add(setting, value)
            End If
        Next
        Return True
    End Function
    Public Function Write(filename As String) As Boolean
        Return True
    End Function
    Public Function Write() As Boolean
        'write the entire inifile structure
        For Each section As String In m_inifile.Keys
            Debug.WriteLine(section)
            For Each setting As String In m_inifile(section).Keys
                Debug.WriteLine(setting & "=" & Encrypt(m_inifile(section)(setting)))
            Next
        Next
        Return True
    End Function
End Class