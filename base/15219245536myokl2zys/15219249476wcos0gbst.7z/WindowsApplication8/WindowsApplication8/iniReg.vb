﻿Imports System.IO
Imports System.Text

Public Class IniReg
    Inherits Dictionary(Of String, Dictionary(Of String, String))

    Default Public Overloads Property Item(Section As String, Key As String, Optional [Default] As String = Nothing) As String
        Get
            Dim SectionDict As Dictionary(Of String, String), Res As String
            Return If(Me.TryGetValue(Section, SectionDict) AndAlso SectionDict.TryGetValue(Key, Res), Res, [Default])
        End Get
        Set(Value As String)
            Dim SectionDict As Dictionary(Of String, String)
            If Not Me.TryGetValue(Section, SectionDict) Then
                SectionDict = New Dictionary(Of String, String)
                Me(Section) = SectionDict
            End If
            SectionDict(Key) = Value
        End Set
    End Property

    Public Shared Function FromFile(Filename As String) As IniReg
        Dim Res As New IniReg, Section As String = "", Line As String, Key As String, Value As New StringBuilder, Q As Integer, I As Integer, Lines() As String

        Lines = File.ReadAllLines(Filename)
        For Q = 0 To Lines.Length - 1
            Line = Lines(Q)
            If Line.Length Then
                If Line(0) = ";"c Then
                    Res(Section, Line) = Nothing
                ElseIf Line(0) = "[" Then
                    Section = Line.Substring(1, Line.Length - 1 + (Line(Line.Length - 1) = "]"c))
                    If Not Res.ContainsKey(Section) Then Res.Add(Section, New Dictionary(Of String, String))
                Else
                    I = Line.IndexOf("="c)
                    If I = -1 Then
                        Res(Section, Line) = Nothing
                    Else
                        Key = Line.Substring(0, I)
                        If Line(Line.Length - 1) <> "\"c Then
                            Res(Section, Key) = Line.Substring(I + 1)
                        Else
                            Value.Append(Line.Substring(I + 1))
                            Do
                                Value.AppendLine()
                                Q += 1
                                If Q = Lines.Length Then Exit Do
                                Line = Lines(Q)
                                Value.Append(Line)
                            Loop While Line(Line.Length - 1) = "\"c
                            Res(Section, Key) = Value.ToString()
                            Value.Clear()
                        End If
                    End If
                End If
            End If
        Next Q

        Return Res
    End Function

    Public Sub Save(Filename As String)
        Dim Res As New List(Of String)

        If Me.ContainsKey("") Then
            For Each Kkvp As KeyValuePair(Of String, String) In Me("")
                Res.Add(If(Kkvp.Value IsNot Nothing, Kkvp.Key & "=" & Kkvp.Value, Kkvp.Key))
            Next Kkvp
        End If

        For Each Skvp As KeyValuePair(Of String, Dictionary(Of String, String)) In Me
            If Skvp.Key.Length Then
                Res.Add("")
                Res.Add("[" + Skvp.Key + "]")
                For Each Kkvp As KeyValuePair(Of String, String) In Skvp.Value
                    Res.Add(If(Kkvp.Value IsNot Nothing, Kkvp.Key & "=" & Kkvp.Value, Kkvp.Key))
                Next Kkvp
            End If
        Next Skvp

        File.WriteAllLines(Filename, Res.ToArray())
    End Sub

End Class
