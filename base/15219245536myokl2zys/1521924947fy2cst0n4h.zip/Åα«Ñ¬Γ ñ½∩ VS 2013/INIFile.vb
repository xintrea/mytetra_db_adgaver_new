﻿Public Class INIFile
    Private ListSections As New SectionsCollection

    Public Class SectionsCollection
        Private SCollection As New Collection

        Public Function Add(name As String) As ValuesCollection
            Dim Result As New ValuesCollection
            SCollection.Add({name, Result}, name)
            Return Result
        End Function

        Public Sub Remove(name As String)
            SCollection.Remove(name)
        End Sub

        Public Sub Clear()
            SCollection.Clear()
        End Sub

        Public ReadOnly Property Count As Integer
            Get
                Return SCollection.Count
            End Get
        End Property

        Public Function GetSection(name As String) As ValuesCollection
            Return SCollection.Item(name)(1)
        End Function

        Public ReadOnly Property Items As String()
            Get
                Dim Result() As String = {}
                For Each item In SCollection
                    ReDim Preserve Result(Result.Length)
                    Result(Result.Length - 1) = item(0)
                Next
                Return Result
            End Get
        End Property

    End Class

    Public Class ValuesCollection
        Private VCollection As New Collection

        Public Sub Add(key As String, value As String)
            VCollection.Add({key, value}, key)
        End Sub

        Public Sub Remove(key As String)
            VCollection.Remove(key)
        End Sub

        Public Sub Clear()
            VCollection.Clear()
        End Sub

        Public ReadOnly Property Count As Integer
            Get
                Return VCollection.Count
            End Get
        End Property

        Public ReadOnly Property Keys As String()
            Get
                Dim Result() As String = {}
                For Each item In VCollection
                    ReDim Preserve Result(Result.Length)
                    Result(Result.Length - 1) = item(0)
                Next
                Return Result
            End Get
        End Property

        Public ReadOnly Property Value(key As String) As String
            Get
                Return VCollection.Item(key)(1)
            End Get
        End Property

        Public ReadOnly Property Value(index As Integer) As String
            Get
                Return VCollection.Item(index + 1)(1)
            End Get
        End Property
    End Class

    Public Sub SaveFile(path As String)
        Using FileText = IO.File.CreateText(path)
            For Each item In Sections.Items
                FileText.WriteLine(String.Format("[{0}]", item))
                For Each key In Sections.GetSection(item).Keys
                    FileText.WriteLine(String.Format("{0} = {1}", {key,
                                                                   Sections.GetSection(item).Value(key)}))
                Next
            Next
        End Using
    End Sub

    Public Sub OpenFile(path As String)
        Sections.Clear()
        Dim VCol As ValuesCollection = Nothing
        For Each Line In IO.File.ReadAllLines(path)
            Line = Line.Trim
            If Line.StartsWith("[") And Line.EndsWith("]") Then

                VCol = Sections.Add(Mid(Line, 2, Line.Length - 2).Trim)
            ElseIf Line Like "*=*" Then
                If Not VCol Is Nothing Then
                    Dim keyName As String = Split(Line, "=")(0).Trim
                    Dim valueData As String = Split(Line, "=")(1).Trim
                    VCol.Add(keyName, valueData)
                End If
            End If
        Next
    End Sub

    Public Function Parse(str As String) As SectionsCollection
        Dim Result As New SectionsCollection
        Dim VCol As ValuesCollection = Nothing
        For Each Line In Split(str, vbNewLine)
            Line = Line.Trim
            If Line.StartsWith("[") And Line.EndsWith("]") Then

                VCol = Result.Add(Mid(Line, 2, Line.Length - 2).Trim)
            ElseIf Line Like "*=*" Then
                If Not VCol Is Nothing Then
                    Dim keyName As String = Split(Line, "=")(0).Trim
                    Dim valueData As String = Split(Line, "=")(1).Trim
                    VCol.Add(keyName, valueData)
                End If
            End If
        Next
        Return Result
    End Function

    Public ReadOnly Property Sections As SectionsCollection
        Get
            Return ListSections
        End Get
    End Property
End Class
