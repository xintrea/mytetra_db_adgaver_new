﻿Public Class MainWindow
    Private INIFileEdit As New INIFile

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If OpenFileDialogMain.ShowDialog = Windows.Forms.DialogResult.OK Then
            Try
                INIFileEdit = New INIFile
                INIFileEdit.OpenFile(OpenFileDialogMain.FileName)
                ComboBox1.Items.Clear()
                ListView1.Items.Clear()
                ComboBox1.Items.AddRange(INIFileEdit.Sections.Items)
                If ComboBox1.Items.Count > 0 Then ComboBox1.SelectedIndex = 0

            Catch ex As Exception
                MsgBox("Не возможно открыть файл!")
            End Try
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim Values = INIFileEdit.Sections.GetSection(ComboBox1.SelectedItem)
        ListView1.Items.Clear()
        For Each key In Values.Keys
            Dim Item As New ListViewItem
            With Item
                .Text = key
                .SubItems.Add(Values.Value(key))
            End With
            ListView1.Items.Add(Item)
        Next
    End Sub
    Private SelectedSection As INIFile.SectionsCollection

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If ComboBox1.SelectedIndex = -1 Then
            MsgBox("Для начала выберите секцию!", MsgBoxStyle.Exclamation, "Внимание!")
        Else
            Dim addForm As New FormLabelEdit
            addForm.Text = "Добавить..."
            While True
                If addForm.ShowDialog = Windows.Forms.DialogResult.OK Then
                    If addForm.TextBox1.Text = "" Then
                        MsgBox("Введите имя!", MsgBoxStyle.Exclamation, "Внимание!")
                    Else
                     
                        Try
                            INIFileEdit.Sections.GetSection(ComboBox1.SelectedItem).Add(addForm.TextBox1.Text, addForm.TextBox2.Text)
                            Dim Item As New ListViewItem
                            With Item
                                .Text = addForm.TextBox1.Text
                                .SubItems.Add(addForm.TextBox2.Text)
                            End With
                            ListView1.Items.Add(Item)
                            Exit While
                        Catch ex As Exception
                            MsgBox("Такое имя уже существует!", MsgBoxStyle.Exclamation, "Внимание!")
                        End Try

                    End If
                End If
            End While
            addForm.Dispose()
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If ComboBox1.SelectedIndex = -1 Then
            MsgBox("Выберите секцию!", MsgBoxStyle.Exclamation, "Внимание!")
        Else
            If MsgBox("Вы точно хотите удалить секцию """ & ComboBox1.SelectedItem & """?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Удаление") = MsgBoxResult.Yes Then
                INIFileEdit.Sections.Remove(ComboBox1.SelectedItem)
                ComboBox1.Items.Clear()
                ListView1.Items.Clear()
                ComboBox1.Items.AddRange(INIFileEdit.Sections.Items)
                If ComboBox1.Items.Count > 0 Then ComboBox1.SelectedIndex = 0
            End If
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim TResult = InputBox("Введите имя секции:", "Добавить секцию")
        If Not TResult = "" Then
            INIFileEdit.Sections.Add(TResult)
            ComboBox1.Items.Add(TResult)
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If ComboBox1.SelectedIndex = -1 Then Exit Sub
        If MsgBox("Вы точно хотите удалить значения?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Удаление") = MsgBoxResult.Yes Then
            For Each item As ListViewItem In ListView1.SelectedItems
                INIFileEdit.Sections.GetSection(ComboBox1.SelectedItem).Remove(item.Text)
                Dim Values = INIFileEdit.Sections.GetSection(ComboBox1.SelectedItem)
                ListView1.Items.Clear()
                For Each key In Values.Keys
                    Dim SItem As New ListViewItem
                    With SItem
                        .Text = key
                        .SubItems.Add(Values.Value(key))
                    End With
                    ListView1.Items.Add(SItem)
                Next
            Next
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If SaveFileDialogMain.ShowDialog = Windows.Forms.DialogResult.OK Then
            INIFileEdit.SaveFile(SaveFileDialogMain.FileName)
        End If
    End Sub
End Class
